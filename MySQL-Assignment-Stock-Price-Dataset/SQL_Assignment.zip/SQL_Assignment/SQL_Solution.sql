#1.Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA. (This has to be done for all 6 stocks)

#1.1.Droping tables if exists
DROP TABLE IF EXISTS `assignment`.`bajaj1`;
DROP TABLE IF EXISTS `assignment`.`eicher1`;
DROP TABLE IF EXISTS `assignment`.`hero1`;
DROP TABLE IF EXISTS `assignment`.`infosys1`;
DROP TABLE IF EXISTS `assignment`.`tcs1`;
DROP TABLE IF EXISTS `assignment`.`tvs1`;

#1.2.Creating tables for all 6 stocks
CREATE TABLE `assignment`.`bajaj1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY KEY (`Date`));

CREATE TABLE `assignment`.`eicher1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`hero1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`infosys1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY	 KEY (`Date`));
  
 CREATE TABLE `assignment`.`tcs1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`tvs1` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `20 Day MA` FLOAT(7,2),
  `50 Day MA` FLOAT(7,2),
  PRIMARY KEY (`Date`));
  
 #1.3.Inserting data in all stock tables
 INSERT INTO `assignment`.`bajaj1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`bajaj auto`;
 
 INSERT INTO `assignment`.`eicher1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`eicher motors`;
 
 INSERT INTO `assignment`.`hero1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`hero motocorp`;
 
 INSERT INTO `assignment`.`infosys1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`infosys`;
 
 INSERT INTO `assignment`.`tcs1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`tcs`;
 
 INSERT INTO `assignment`.`tvs1` (
 `Date`,`Close Price`,`20 Day MA`,`50 Day MA`)
 SELECT `Date`,`Close Price`, 
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 19 THEN (avg(`Close Price`) over (order by `Date` rows between 19 preceding and current row)) ELSE null END),2),
 ROUND((CASE WHEN (row_number() over (order by `Date`)) > 49 THEN (avg(`Close Price`) over (order by `Date` rows between 49 preceding and current row)) ELSE null END),2) 
 FROM `assignment`.`tvs motors`;
 
#2.Create Master tables for date and close price of all the six stocks
#2.1.Droping table if exists
DROP TABLE IF EXISTS `assignment`.`master`;

#2.2.Creating master table
CREATE TABLE `assignment`.`master` (
  `Date` DATE NOT NULL,
  `Bajaj` FLOAT(7,2) NOT NULL,
  `TCS` FLOAT(7,2) NOT NULL,
  `TVS` FLOAT(7,2) NOT NULL,
  `Infosys` FLOAT(7,2) NOT NULL,
  `Eicher` FLOAT(7,2) NOT NULL,
  `Hero` FLOAT(7,2) NOT NULL,
  PRIMARY KEY (`Date`));
  
#2.3.Inserting Data into master table
INSERT INTO `assignment`.`master` (
  `Date`, `Bajaj`,`TCS`,`TVS`,`Infosys`,`Eicher`,`Hero`)
  SELECT `ba`.`Date`,`ba`.`Close Price`,`tc`.`Close Price`,`tvm`.`Close Price`,`inf`.`Close Price`,`em`.`Close Price`,`hm`.`Close Price` 
  FROM `assignment`.`bajaj auto` `ba`,`assignment`.`eicher motors` `em`,`assignment`.`Infosys` `inf`,
  `assignment`.`hero motocorp` `hm`,`assignment`.`tcs` `tc`,`assignment`.`tvs motors` `tvm` WHERE
  `ba`.`Date` = `em`.`Date` and `ba`.`Date` = `inf`.`Date` and `ba`.`Date` = `hm`.`Date` and
  `ba`.`Date` = `tc`.`Date` and `ba`.`Date` = `tvm`.`Date`;
  
#3.Generate buy and sell signal and store in different tables  
#3.1Droping Table if exist
DROP TABLE IF EXISTS `assignment`.`bajaj2`;
DROP TABLE IF EXISTS `assignment`.`eicher2`;
DROP TABLE IF EXISTS `assignment`.`hero2`;
DROP TABLE IF EXISTS `assignment`.`infosys2`;
DROP TABLE IF EXISTS `assignment`.`tcs2`;
DROP TABLE IF EXISTS `assignment`.`tvs2`;

#3.2.Creating tables to store buy and sell signal. 
CREATE TABLE `assignment`.`bajaj2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));

CREATE TABLE `assignment`.`eicher2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`hero2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`infosys2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`tcs2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));
  
 CREATE TABLE `assignment`.`tvs2` (
  `Date` DATE NOT NULL,
  `Close Price` FLOAT(7,2) NOT NULL,
  `Signal` VARCHAR(4),
  PRIMARY KEY (`Date`));
  
#3.3.Inserting data for Buy/Sell Signals
 INSERT INTO `assignment`.`bajaj2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`bajaj1` WHERE `50 DAY MA` IS NOT NULL;
 
 INSERT INTO `assignment`.`eicher2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`eicher1` WHERE `50 DAY MA` IS NOT NULL;
 
 INSERT INTO `assignment`.`hero2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`hero1` WHERE `50 DAY MA` IS NOT NULL;
 
 INSERT INTO `assignment`.`infosys2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`infosys1` WHERE `50 DAY MA` IS NOT NULL;
 
 INSERT INTO `assignment`.`tcs2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`tcs1` WHERE `50 DAY MA` IS NOT NULL;
 
 INSERT INTO `assignment`.`tvs2` (
 `Date`,`Close Price`,`Signal`)
 SELECT `Date`,`Close Price`, 
 (CASE WHEN `20 Day MA` > `50 Day MA` THEN 'BUY' WHEN `20 Day MA` < `50 Day MA` THEN 'SELL' ELSE 'HOLD' END) 
 FROM `assignment`.`tvs1` WHERE `50 DAY MA` IS NOT NULL;
 
  
#4.Creating User defined function, that takes the date as input and returns the signal
drop function if exists signal_for_bajaj;
delimiter |
CREATE FUNCTION signal_for_bajaj( stock_date DATE)
	RETURNS VARCHAR(4)
		DETERMINISTIC
			BEGIN
				DECLARE stock_signal VARCHAR(4);
                DECLARE short_ma FLOAT(7,2);
                DECLARE long_ma FLOAT(7,2);
					SELECT `20 Day MA`, `50 Day MA` INTO short_ma, long_ma FROM `assignment`.`bajaj1` WHERE `DATE` = stock_date;
						IF (short_ma > long_ma) 
							THEN SET stock_signal = 'BUY';
						ELSEIF (short_ma < long_ma) 
							THEN SET stock_signal = 'SELL';
						ELSE
							SET stock_signal = 'HOLD';
						END IF;
				RETURN stock_signal;

			END|
delimiter ;